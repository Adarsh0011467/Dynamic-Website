const router=require('express').Router()
const Banner=require('../models/banner')
const Service=require('../models/service')
const Testi=require('../models/testi')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')
const Contact=require('../models/contact')
const multer=require('multer')


const storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

const upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})

router.get('/',async(req,res)=>{
    const testirecord=await Testi.find({status:'publish'})
    const footer=await Contact.findOne()
    const bannerrecord=await Banner.findOne()
    const servicerecord=await Service.find({status:'publish'})
    res.render('index.ejs',{bannerrecord,servicerecord,testirecord,footer})
})

router.get('/banner',bannerc.bannershow)
router.post('/query',queryc.queryinsert)
router.get('/servicepage/:id',servicec.servicesinglerecord)
router.get('/testi',testic.testi)
router.post('/testi',upload.single('image'),testic.testiform)












module.exports=router