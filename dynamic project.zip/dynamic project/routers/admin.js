const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const queryc=require('../controllers/querycontroller')
const testic=require('../controllers/testicontroller')
const contactc=require('../controllers/contactcontroller')
const Reg=require('../models/reg')
const bcrypt=require('bcrypt')
const multer=require('multer')




function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }
    else{
        res.redirect('/admin')
    }
}
const storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

const upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})



router.get('/',regc.adminloginshow)
router.post('/loginrecord',async(req,res)=>{
    const{us,pass}=req.body
    const record=await Reg.findOne({username:us})
   // console.log(record)
   if(record!==null){
    const comparepass=await bcrypt.compare(pass,record.password)
   if(comparepass){
    req.session.isAuth=true
    res.redirect('/admin/dashboard')
   }else{
    res.redirect('/admin')
   }
}else{
    res.redirect('/admin')
   }
})
router.get('/dashboard',handlelogin,regc.admindashboard)
router.get('/logout',regc.adminlogout)
router.get('/banner',bannerc.adminbannershow)
router.get('/bannerupdate/:id',bannerc.bannerupdate)
router.post('/bannerupdaterecord/:id',upload.single('img'),bannerc.bannerrecord)
router.get('/service',servicec.adminserviceshow)
router.get('/serviceadd',servicec.serviceadd)
router.post('/serviceadd',upload.single('img'),servicec.servicerecord)
router.get('/servicedelete/:id',servicec.servicedelete)
router.get('/serviceupdate/:id',servicec.serviceupdate)
router.get('/query',queryc.queryallselection)
router.get('/queryreply/:id',queryc.queryform)
router.post('/queryreply/:id',upload.single('attachment'),queryc.sendquerymail)
router.get('/testi',testic.testiselection)
router.get('/testirecorddelete/:id',testic.testirecorddelete)
router.get('/testiupdate/:id',testic.testiupdate)
router.get('/contact',contactc.showall)
router.get('/contactupdate/:id',contactc.contactupdate)
router.post('/contactupdate/:id',contactc.contactupdaterecords)
router.post('/servicesearch',servicec.servicesearch)
router.post('/testisearch',testic.testisearch)













router.get('/test',regc.test)
router.get('/test2',bannerc.test2)













module.exports=router