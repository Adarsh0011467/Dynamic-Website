const mongoose=require('mongoose')

const contactSchema=mongoose.Schema({
    address:String,
    tel:Number,
    phone:Number,
    email:String,
    insta:String,
    linkedin:String,
    twitter:String,
    snapchat:String
})




module.exports=mongoose.model('contact',contactSchema)