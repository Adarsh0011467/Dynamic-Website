const Testi=require('../models/testi')
const Contact =require('../models/contact')



exports.testi=async(req,res)=>{
    const footer=await Contact.findOne()
    res.render('testiform.ejs',{footer})
}
exports.testiform=(req,res)=>{
 const filename=req.file.filename
 const{ldesc,name}=req.body
 const record=new Testi({img:filename,ldesc:ldesc,name:name})
 record.save()
 //console.log(record)
 res.redirect('/')
}
exports.testiselection=async(req,res)=>{
  const record=await Testi.find().sort({postedDate:-1}) //.sort({postedDate:-1})
  const totaltesti=await Testi.count()
  const publish=await Testi.count({status:'publish'})
  const unpublish=await Testi.count({status:'unpublish'})
   res.render('admin/testi.ejs',{record,totaltesti,publish,unpublish})
}

exports.testirecorddelete=async(req,res)=>{
   const id=req.params.id
   await Testi.findByIdAndDelete(id)
   res.redirect('/admin/testi')
}

exports.testiupdate=async(req,res)=>{
     const id=req.params.id
     const record=await Testi.findById(id)
     let newstatus=null
     if(record.status=='unpublish'){
        newstatus='publish'
     }else{
        newstatus='unpublish'
     }
     await Testi.findByIdAndUpdate(id,{status:newstatus})
     res.redirect('/admin/testi')
}

exports.testisearch=async(req,res)=>{
   const{search}=req.body
  const record=await Testi.find({status:search})
  const totaltesti=await Testi.count()
  const publish=await Testi.count({status:'publish'})
  const unpublish=await Testi.count({status:'unpublish'})
   res.render('admin/testi.ejs',{record,totaltesti,publish,unpublish})
}