const Service=require("../models/service")
const Contact=require('../models/contact')


exports.adminserviceshow=async(req,res)=>{
  const record=await Service.find().sort({postedDate:-1})
  const totalservices=await Service.count()
  const publish=await Service.count({status:'publish'})
  const unpublish=await Service.count({status:'unpublish'})
  //console.log(publish)
  res.render('admin/service.ejs',{record,totalservices,publish,unpublish})
}

exports.serviceadd=(req,res)=>{
 res.render('admin/serviceform.ejs')
}

exports.servicerecord= (req,res)=>{
  const{sname,sdesc,sldesc}=req.body
  const filename=req.file.filename
  const record=new Service({name:sname,desc:sdesc,ldesc:sldesc,img:filename})
  record.save()
  res.redirect('/admin/service')
}

exports.servicedelete=async(req,res)=>{
const id=req.params.id
await Service.findByIdAndDelete(id)
res.redirect('/admin/service')
}

exports.serviceupdate=async(req,res)=>{
const id=req.params.id
const record=await Service.findById(id)
//console.log(record.status)
let newstatus=null
if(record.status=='unpublish'){
   newstatus='publish'
}else{
  newstatus='unpublish'
}
await Service.findByIdAndUpdate(id,{status:newstatus})
res.redirect('/admin/service')
}

exports.servicesinglerecord=async(req,res)=>{
  const id=req.params.id
  const footer=await Contact.findOne()
 const record= await Service.findById(id)
  res.render('service.ejs',{record,footer})
}

exports.servicesearch=async(req,res)=>{
   const{search}=req.body
   const record=await Service.find({status:search})
   const totalservices=await Service.count()
  const publish=await Service.count({status:'publish'})
  const unpublish=await Service.count({status:'unpublish'})
  res.render('admin/service.ejs',{record,totalservices,publish,unpublish})
}