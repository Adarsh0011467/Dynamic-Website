const Contact=require('../models/contact')


exports.showall=async(req,res)=>{
    const record=await Contact.findOne()
  res.render('admin/contact.ejs',{record})
}
exports.contactupdate=async(req,res)=>{
     const id=req.params.id
     const record=await Contact.findById(id)
     res.render('admin/contactupdateform.ejs',{record})
}

exports.contactupdaterecords=async(req,res)=>{
     const id=req.params.id
     const{address,tel,phone,email,insta,linkedin,twitter,snap}=req.body
     await Contact.findByIdAndUpdate(id,{address:address,tel:tel,phone:phone,email:email,insta:insta,linkedin:linkedin,twitter:twitter,snapchat:snap})
     res.redirect('/admin/contact')
}