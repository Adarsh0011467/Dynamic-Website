const Reg=require('../models/reg')
const bcrypt=require('bcrypt')




exports.adminloginshow=(req,res)=>{
    res.render('admin/login.ejs')
}
exports.admindashboard=(req,res)=>{
   // console.log(req.session)
    res.render('admin/dashboard.ejs')
}


exports.adminlogout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin')
}


// --------------------dummy url-------------------------- //

exports.test= async(req,res)=>{
    let pass='123'
   const cpass= await bcrypt.hash(pass,10)
   const record= new Reg({username:'admin1',password:cpass})
   record.save()
}






